Tavatar Recoloring HUD Kit
Version 1.0
by Tapple Gao

This contains the source files used to create the Recolor HUD Kit available at:
https://marketplace.secondlife.com/p/Recoloring-HUD-Kit/4299174

All textures were created using Inkscape, my preferred vector image editor:

http://inkscape.org

The svg files are the inkscape source files.